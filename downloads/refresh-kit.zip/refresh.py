#!/usr/bin/env python3
"""Deterministic portfolio refresh using Python 3 standard library only."""
import argparse
import hashlib
import html
import json
import re
from datetime import date
from decimal import Decimal
from pathlib import Path

ABILITIES = ('자기조절력', '대인관계력', '자기동기력')
OWN_FIELDS = ('강점이 드러난 일화:', '강점을 위해 노력하고 생각한 것:', '나에게 남기는 말:', '내가 나눈 감사:')
KEYWORDS = {
    '자기조절력': ('감정', '화가', '짜증', '차분', '침착', '조절', '충분히 자', '잠도'),
    '대인관계력': ('서로', '도와', '도움', '동료', '함께', '챙겨', '소통', '질문'),
    '자기동기력': ('포기', '끝까지', '마쳤', '완료', '공부', '열심', '다시', '계획'),
}

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n'

def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()

def read(path, default=None):
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else default

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(canonical(value), encoding='utf-8', newline='\n')

def checked_date(value, month_ok=False):
    if not isinstance(value, str): raise ValueError('날짜는 문자열이어야 합니다.')
    if month_ok and re.fullmatch(r'\d{4}-\d{2}', value):
        date.fromisoformat(value+'-01')
    else:
        if date.fromisoformat(value).isoformat() != value: raise ValueError('날짜 형식 오류')
    return value

def integer(value):
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0

def collect(input_dir):
    raw = read(input_dir/'ritual.json')
    if not isinstance(raw, dict) or not isinstance(raw.get('days'), list):
        raise ValueError('input/ritual.json에 days 배열이 필요합니다.')
    days = {}
    signals = set()
    for entry in raw['days']:
        when = checked_date(entry['date'])
        opening, closing = entry.get('open'), entry.get('close')
        # Private export arrays and the supplied privacy-minimized boolean input are supported.
        if opening is not None and not isinstance(opening, (list, bool)):
            raise ValueError('open은 배열 또는 기록 유무여야 합니다.')
        if closing is not None and not isinstance(closing, (list, bool)):
            raise ValueError('close는 배열 또는 기록 유무여야 합니다.')
        if not opening and not closing: continue
        row = days.setdefault(when, {'opening': False, 'closing': False})
        row['opening'] |= bool(opening)
        row['closing'] |= bool(closing)
        for ability in entry.get('signals', []):
            if ability not in ABILITIES: raise ValueError('알 수 없는 능력 분류')
            signals.add((when, ability))
        own_text = []
        for field in (opening, closing):
            if isinstance(field, list):
                own_text.extend(x for x in field if isinstance(x, str) and x.startswith(OWN_FIELDS))
        # Do not copy free text, peer names, messages, or contacts into public results.
        for ability, words in KEYWORDS.items():
            if any(word in text for word in words for text in own_text):
                signals.add((when, ability))
    if not days: raise ValueError('집계할 리추얼 기록이 없습니다.')
    ordered = sorted(days)
    week_counts = {}
    for when in ordered:
        iso = date.fromisoformat(when).isocalendar()
        week = '%04d-W%02d' % (iso.year, iso.week)
        week_counts[week] = week_counts.get(week, 0) + 1
    metrics = {
        'recordedDays': len(days),
        'openingDays': sum(x['opening'] for x in days.values()),
        'closingDays': sum(x['closing'] for x in days.values()),
        'recordedCalendarWeeks': len(week_counts),
    }
    tasks = read(input_dir/'tasks.json', {'items': []})
    items = tasks.get('items', [])
    if not isinstance(items, list): raise ValueError('tasks.items는 배열이어야 합니다.')
    ids = [x['id'] for x in items]
    if len(ids) != len(set(ids)): raise ValueError('과제 ID가 중복되었습니다.')
    for item in items:
        if not re.fullmatch(r'T\d{2}', item['id']): raise ValueError('과제 ID 형식 오류')
        checked_date(item['date'], month_ok=True)
        if item['ability'] not in ABILITIES: raise ValueError('과제 능력 분류 오류')
        if item['status'] not in ('completed', 'in_progress', 'planned'): raise ValueError('과제 상태 오류')
    metrics['selectedTasks'] = len(items)
    metrics['completedSelectedTasks'] = sum(x['status'] == 'completed' for x in items)
    attendance = read(input_dir/'attendance.json', {})
    a, total = attendance.get('attended_days'), attendance.get('scheduled_days')
    if a is None and total is None:
        attendance_result = None
    else:
        if not integer(a) or not integer(total) or a > total:
            raise ValueError('출석은 0 이상 정수이고 출석일은 대상 수업일을 넘을 수 없습니다.')
        attendance_result = {'attendedDays': a, 'scheduledDays': total,
            'percent': format(Decimal(a)*100/Decimal(total), '.1f') if total else None,
            'asOf': checked_date(attendance['as_of'])}
    candidates = []
    # At most three recent candidates per ability, in a stable order.
    for ability in ABILITIES:
        recent = sorted((d for d, kind in signals if kind == ability), reverse=True)[:3]
        for when in sorted(recent):
            text = when+' 리추얼에서 '+ability+'과 관련된 경험과 생각을 돌아보았습니다.'
            evidence = {'source': '리추얼 기록', 'file': 'input/ritual.json', 'date': when,
                        'field': '본인 경험과 회고의 능력 관련 표현', 'rule': 'keyword-v1'}
            content = {'ability': ability, 'date': when, 'text': text, 'evidence': evidence}
            candidates.append({'id': 'ritual-'+digest(content)[:16], **content, 'content_sha256': digest(content)})
    for item in sorted(items, key=lambda x: x['id']):
        if item['status'] != 'completed': continue
        # IDs, approved capability names, and validated dates only; free titles are not exported.
        evidence = {'source': '선정 과제 목록', 'file': 'input/tasks.json', 'task': item['id'],
                    'date': item['date'], 'field': 'status=completed', 'rule': 'task-status-v1'}
        content = {'ability': item['ability'], 'date': item['date'],
                   'text': item['date']+'에 '+item['id']+' 과제를 완료했습니다.', 'evidence': evidence}
        candidates.append({'id': 'task-'+digest(content)[:16], **content, 'content_sha256': digest(content)})
    candidates.sort(key=lambda x: (x['ability'], x['date'], x['id']))
    source = {'ritual': {'name': '리추얼 기록', 'file': 'input/ritual.json',
              'periodStart': ordered[0], 'periodEnd': ordered[-1]},
              'tasks': {'name': '선정 과제 목록', 'file': 'input/tasks.json', 'scope': '선정한 과제만 집계하며 전체 제출률이 아님'},
              'attendance': {'name': '내 출석 기록', 'file': 'input/attendance.json',
                             'available': attendance_result is not None}}
    after = [d for d in ordered if '2026-10-20' < d <= '2026-10-30']
    return {'schemaVersion': 1, 'asOf': ordered[-1], 'metrics': metrics, 'sources': source,
            'attendance': attendance_result, 'weeks': week_counts,
            'days': [{'date': d, **days[d]} for d in ordered],
            'storyEvidence': {'date': '2026-10-20', 'followingPeriod': '2026-10-21~2026-10-30',
                              'recordedDays': len(after), 'dates': after}}, candidates

def generate(input_dir, output_dir):
    summary, candidates = collect(input_dir)
    approvals = read(input_dir/'approvals.json', {'approved': []})
    by_id = {x['id']: x for x in candidates}
    approved = []
    rejected = []
    for choice in approvals.get('approved', []):
        candidate = by_id.get(choice.get('id'))
        if candidate is None or candidate['content_sha256'] != choice.get('content_sha256'):
            rejected.append(choice.get('id', 'unknown'))
        elif candidate['id'] not in {x['id'] for x in approved}:
            approved.append(candidate)
    if rejected:
        raise ValueError('기존 후보가 바뀌었습니다. 다시 확인하고 승인하세요: '+', '.join(sorted(rejected)))
    approved.sort(key=lambda x: (x['ability'], x['date'], x['id']))
    public = {**summary, 'approvedParagraphs': approved}
    write(output_dir/'summary.json', summary)
    write(output_dir/'candidates.json', {'notice': '문장 후보입니다. 사실과 능력 해석을 확인한 뒤 승인하세요. 후보 생성은 능력 점수 측정이 아닙니다.', 'candidates': candidates})
    write(output_dir/'site-data.json', public)
    write(output_dir/'approval-status.json', {'approvedCount': len(approved), 'candidateCount': len(candidates)})
    return public, candidates

def approve(input_dir, output_dir, ids):
    _, candidates = generate(input_dir, output_dir)
    by_id = {x['id']: x for x in candidates}
    current = read(input_dir/'approvals.json', {'approved': []})
    approved = {x['id']: x for x in current['approved']}
    for key in ids:
        if key not in by_id: raise ValueError('현재 결과에 없는 후보 ID: '+key)
        approved[key] = {'id': key, 'content_sha256': by_id[key]['content_sha256']}
    write(input_dir/'approvals.json', {'approved': sorted(approved.values(), key=lambda x: x['id'])})
    generate(input_dir, output_dir)

def numbers_html(data):
    m = data['metrics']; source = data['sources']['ritual']
    period = source['periodStart']+'~'+source['periodEnd']
    values = [(m['recordedDays'], '일', '기록을 남긴 날', '시작 또는 마무리 기록이 있는 날짜를 하루에 한 번 셌습니다.', '리추얼 기록'),
              (m['closingDays'], '일', '하루를 돌아본 날', '마무리 기록에 내용이 있는 날짜만 셌습니다.', '리추얼 기록'),
              (m['recordedCalendarWeeks'], '주', '기록이 있는 달력주', '월요일부터 일요일까지 기준이며 공식 교육 주차와는 구분합니다.', '리추얼 기록')]
    if m['selectedTasks']:
        values.append((m['completedSelectedTasks'], '건', '완료한 선정 과제', '선정 목록 '+str(m['selectedTasks'])+'개 중 완료한 과제입니다. 전체 과제 제출률을 뜻하지 않습니다.', '선정 과제 목록'))
    if data['attendance']:
        a = data['attendance']
        values.append((a['attendedDays'], '일', '출석한 날', '대상 수업일 '+str(a['scheduledDays'])+'일 / 기준일 '+a['asOf'], '내 출석 기록'))
    cards = ''.join('<div class="metric"><p class="metric-value">'+str(n)+'<span>'+unit+'</span></p><h3>'+title+'</h3><p>'+desc+'</p><p class="metric-source">출처: '+src+' · '+(period if src=='리추얼 기록' else 'input/'+('tasks.json' if src=='선정 과제 목록' else 'attendance.json'))+'</p></div>' for n,unit,title,desc,src in values)
    after = data['storyEvidence']
    recovery = ''
    if after['recordedDays']:
        recovery = '<aside class="recovery"><h3>진도가 늦었던 날 이후에도, '+str(after['recordedDays'])+'일의 기록</h3><p>10월 20~21일 공부 진도가 늦고 계획에 못 미쳤다고 기록했지만, 21일에는 충분히 자고 다음 날 더 해보자는 말을 남겼습니다. 10월 21~30일 중 '+str(after['recordedDays'])+'일에 기록을 이어갔습니다.</p><p class="metric-source">출처: 리추얼 기록 · '+html.escape(', '.join(after['dates']))+'</p><a href="#slow-days" class="text-link">당시의 이야기 읽기</a></aside>'
    detail = '<details class="source-details"><summary>숫자의 출처와 계산 기준</summary><div><p>리추얼 원본의 날짜를 중복 제거해 계산했습니다. 기록 '+str(m['recordedDays'])+'일, 시작 '+str(m['openingDays'])+'일, 마무리 '+str(m['closingDays'])+'일입니다. 기록 횟수는 출석일·과제 완료 건수·능력 검사 점수와 다릅니다. 달력주는 월~일 기준입니다.</p><p>선정 과제는 목록에 있는 과제만 셉니다. 출석 원자료가 없으면 출석 수치를 표시하지 않습니다.</p><a class="text-link" href="data/site-data.json">집계 근거 보기 (JSON)</a></div></details>'
    return '<section class="evidence-section" id="numbers" aria-labelledby="numbers-title"><div class="section-head"><h2 id="numbers-title">숫자로 보는 과정</h2><p>'+data['asOf']+' 기준</p></div><p class="section-lead">뜻대로 되지 않은 날에도 기록을 이어갔습니다.</p><div class="metrics">'+cards+'</div>'+recovery+detail+'</section>'

def build(input_dir, output_dir, site):
    public, _ = generate(input_dir, output_dir)
    page = site/'index.html'
    content = page.read_text(encoding='utf-8')
    start = content.index('<section class="evidence-section" id="numbers"')
    end = content.index('<section class="evidence-section" id="work"', start)
    content = content[:start]+numbers_html(public)+content[end:]
    approved = public['approvedParagraphs']
    section = ''
    if approved:
        section = '<section class="evidence-section" id="approved-records"><h2>승인한 새 기록</h2>'
        for item in approved:
            section += '<h3>'+html.escape(item['ability'])+'</h3><p>'+html.escape(item['text'])+'</p><p class="metric-source">'+html.escape(item['date']+' · '+item['evidence']['source'])+'</p>'
        section += '</section>'
    block = '<!-- APPROVED-START -->'+section+'<!-- APPROVED-END -->'
    if '<!-- APPROVED-START -->' in content:
        content = re.sub(r'<!-- APPROVED-START -->.*?<!-- APPROVED-END -->', lambda _: block, content, flags=re.S)
    else:
        content = content.replace('</article><div class="next">', '</article>'+block+'<div class="next">', 1)
    if block not in content: raise ValueError('승인 문단을 넣을 위치를 찾지 못했습니다.')
    page.write_text(content, encoding='utf-8', newline='\n')
    write(site/'data/site-data.json', public)

def main():
    parser = argparse.ArgumentParser(description='새 기록을 집계하고 승인한 문장만 사이트에 반영합니다.')
    parser.add_argument('command', choices=('generate', 'approve', 'build'))
    parser.add_argument('--input', type=Path, default=Path('input'))
    parser.add_argument('--output', type=Path, default=Path('output'))
    parser.add_argument('--site', type=Path, default=Path('site'))
    parser.add_argument('--id', action='append', default=[])
    args = parser.parse_args()
    try:
        if args.command == 'generate': generate(args.input, args.output)
        elif args.command == 'approve':
            if not args.id: raise ValueError('--id로 검토한 후보를 지정하세요.')
            approve(args.input, args.output, args.id)
        else: build(args.input, args.output, args.site)
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as exc:
        parser.exit(1, '오류: '+str(exc)+'\n')
    print('완료: '+args.command)

if __name__ == '__main__': main()
