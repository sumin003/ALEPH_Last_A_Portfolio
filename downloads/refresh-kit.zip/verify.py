#!/usr/bin/env python3
"""Exercise the exact README commands in clean temporary directories."""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def run(folder, *args, ok=True):
    result = subprocess.run([sys.executable, 'refresh.py', *args], cwd=folder,
                            capture_output=True, text=True, encoding='utf-8')
    if (result.returncode == 0) != ok:
        raise AssertionError(result.stderr or result.stdout)
    return result

def hashes(folder):
    return {str(p.relative_to(folder)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.rglob('*')) if p.is_file()}

def main():
    checks = {}
    with tempfile.TemporaryDirectory() as temporary:
        fresh = Path(temporary)/'fresh'
        fresh.mkdir()
        shutil.copy(ROOT/'refresh.py', fresh/'refresh.py')
        shutil.copytree(ROOT/'input', fresh/'input')
        shutil.copytree(ROOT/'site', fresh/'site')
        # This tests the ordinary generate/build commands exactly as documented.
        run(fresh, 'generate', '--input', 'input', '--output', 'output')
        run(fresh, 'build', '--input', 'input', '--output', 'output', '--site', 'site')
        first = {'output': hashes(fresh/'output'), 'site': hashes(fresh/'site')}
        run(fresh, 'generate', '--input', 'input', '--output', 'output')
        run(fresh, 'build', '--input', 'input', '--output', 'output', '--site', 'site')
        second = {'output': hashes(fresh/'output'), 'site': hashes(fresh/'site')}
        checks['sameInputSameBytes'] = first == second
        checks['freshFolderReadmeCommands'] = True
        public = json.loads((fresh/'output/site-data.json').read_text(encoding='utf-8'))
        checks['unapprovedParagraphsExcluded'] = public['approvedParagraphs'] == []
        checks['missingAttendanceIsNotZero'] = public['attendance'] is None
        choices = json.loads((fresh/'output/candidates.json').read_text(encoding='utf-8'))['candidates']
        key = choices[0]['id']
        run(fresh, 'approve', '--id', key)
        run(fresh, 'build')
        approved = json.loads((fresh/'output/site-data.json').read_text(encoding='utf-8'))['approvedParagraphs']
        checks['onlyExplicitlyApprovedParagraphPublished'] = len(approved) == 1 and approved[0]['id'] == key
        checks['approvedParagraphInHtml'] = choices[0]['text'] in (fresh/'site/index.html').read_text(encoding='utf-8')
        approval_path = fresh/'input/approvals.json'
        tampered = json.loads(approval_path.read_text(encoding='utf-8'))
        tampered['approved'][0]['content_sha256'] = '0'*64
        approval_path.write_text(json.dumps(tampered), encoding='utf-8')
        run(fresh, 'build', ok=False)
        checks['approvalMismatchRejected'] = True
        approval_path.write_text('{"approved": []}', encoding='utf-8')
        attendance_path = fresh/'input/attendance.json'
        attendance_path.write_text('{"attended_days":4,"scheduled_days":3,"as_of":"2026-10-30"}', encoding='utf-8')
        run(fresh, 'generate', ok=False)
        checks['invalidAttendanceRejected'] = True
        shutil.copy(ROOT/'input/attendance.json', attendance_path)
        ritual_path = fresh/'input/ritual.json'
        ritual = json.loads(ritual_path.read_text(encoding='utf-8'))
        old_count = public['metrics']['recordedDays']
        ritual['days'].append({'date': '2099-01-01', 'open': True, 'close': False, 'signals': ['자기동기력']})
        ritual_path.write_text(json.dumps(ritual), encoding='utf-8')
        run(fresh, 'build')
        newer = json.loads((fresh/'output/site-data.json').read_text(encoding='utf-8'))
        checks['newRecordUpdatesNumbers'] = newer['metrics']['recordedDays'] == old_count + 1
        checks['newRecordStillNeedsApproval'] = newer['approvedParagraphs'] == []
    if not all(checks.values()): raise AssertionError(checks)
    report = {'checks': checks, 'comparison': {'run1': first, 'run2': second},
              'note': '승인 시험은 임시 폴더에서만 수행했습니다. 실제 제출본의 새 후보 승인 수는 0입니다.'}
    path = ROOT/'verification/comparison.json'
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2)+'\n', encoding='utf-8', newline='\n')
    print('PASS: '+str(len(checks))+' checks; run1 and run2 match byte for byte')

if __name__ == '__main__': main()
